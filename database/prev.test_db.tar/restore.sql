--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 13.2 (Debian 13.2-1.pgdg100+1)
-- Dumped by pg_dump version 13.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE test_db;
--
-- Name: test_db; Type: DATABASE; Schema: -; Owner: root
--

CREATE DATABASE test_db WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'en_US.utf8';


ALTER DATABASE test_db OWNER TO root;

\connect test_db

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: AccountResponses; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public."AccountResponses" (
    acr_id integer NOT NULL,
    billing bigint NOT NULL,
    account bigint NOT NULL,
    "customerId" bigint NOT NULL,
    "contractNumber" bigint NOT NULL,
    imsi bigint NOT NULL,
    "terminalDeviceId" bigint NOT NULL,
    "marketingCategoryId" character varying NOT NULL,
    date_from character varying NOT NULL,
    date_to character varying NOT NULL,
    date_modified double precision NOT NULL,
    msisdn bigint NOT NULL
);


ALTER TABLE public."AccountResponses" OWNER TO root;

--
-- Name: Accounts; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public."Accounts" (
    acc_id integer NOT NULL,
    account bigint NOT NULL,
    terminal_device_id bigint NOT NULL,
    imsi bigint NOT NULL,
    msisdn bigint NOT NULL,
    account_closed bigint NOT NULL,
    load_id bigint NOT NULL,
    contract_closed bigint NOT NULL,
    customer_id bigint NOT NULL,
    contract_number bigint NOT NULL,
    service_provider_id bigint NOT NULL,
    terminal_device_closed bigint NOT NULL,
    deleted bigint NOT NULL,
    date_from character varying NOT NULL,
    date_to character varying NOT NULL,
    marketing_category_id character varying NOT NULL,
    billing bigint
);


ALTER TABLE public."Accounts" OWNER TO root;

--
-- Name: Accounts_acc_id_seq; Type: SEQUENCE; Schema: public; Owner: root
--

ALTER TABLE public."Accounts" ALTER COLUMN acc_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public."Accounts_acc_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: Features; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public."Features" (
    ft_id integer NOT NULL,
    feature character varying,
    description character varying
);


ALTER TABLE public."Features" OWNER TO root;

--
-- Name: Features_ft_id_seq; Type: SEQUENCE; Schema: public; Owner: root
--

ALTER TABLE public."Features" ALTER COLUMN ft_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public."Features_ft_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: ParamScenarios; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public."ParamScenarios" (
    ps_id integer NOT NULL,
    sc_id integer NOT NULL,
    param_name character varying,
    param_value character varying
);


ALTER TABLE public."ParamScenarios" OWNER TO root;

--
-- Name: ScenarioAccountResponses; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public."ScenarioAccountResponses" (
    sc_id integer NOT NULL,
    acr_id integer NOT NULL
);


ALTER TABLE public."ScenarioAccountResponses" OWNER TO root;

--
-- Name: ScenarioAccounts; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public."ScenarioAccounts" (
    acc_id integer NOT NULL,
    sc_id integer NOT NULL
);


ALTER TABLE public."ScenarioAccounts" OWNER TO root;

--
-- Name: Scenarios; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public."Scenarios" (
    sc_id integer NOT NULL,
    ft_id integer NOT NULL,
    description character varying NOT NULL,
    http_status_code character varying
);


ALTER TABLE public."Scenarios" OWNER TO root;

--
-- Data for Name: AccountResponses; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public."AccountResponses" (acr_id, billing, account, "customerId", "contractNumber", imsi, "terminalDeviceId", "marketingCategoryId", date_from, date_to, date_modified, msisdn) FROM stdin;
\.
COPY public."AccountResponses" (acr_id, billing, account, "customerId", "contractNumber", imsi, "terminalDeviceId", "marketingCategoryId", date_from, date_to, date_modified, msisdn) FROM '$$PATH$$/2980.dat';

--
-- Data for Name: Accounts; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public."Accounts" (acc_id, account, terminal_device_id, imsi, msisdn, account_closed, load_id, contract_closed, customer_id, contract_number, service_provider_id, terminal_device_closed, deleted, date_from, date_to, marketing_category_id, billing) FROM stdin;
\.
COPY public."Accounts" (acc_id, account, terminal_device_id, imsi, msisdn, account_closed, load_id, contract_closed, customer_id, contract_number, service_provider_id, terminal_device_closed, deleted, date_from, date_to, marketing_category_id, billing) FROM '$$PATH$$/2981.dat';

--
-- Data for Name: Features; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public."Features" (ft_id, feature, description) FROM stdin;
\.
COPY public."Features" (ft_id, feature, description) FROM '$$PATH$$/2983.dat';

--
-- Data for Name: ParamScenarios; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public."ParamScenarios" (ps_id, sc_id, param_name, param_value) FROM stdin;
\.
COPY public."ParamScenarios" (ps_id, sc_id, param_name, param_value) FROM '$$PATH$$/2985.dat';

--
-- Data for Name: ScenarioAccountResponses; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public."ScenarioAccountResponses" (sc_id, acr_id) FROM stdin;
\.
COPY public."ScenarioAccountResponses" (sc_id, acr_id) FROM '$$PATH$$/2986.dat';

--
-- Data for Name: ScenarioAccounts; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public."ScenarioAccounts" (acc_id, sc_id) FROM stdin;
\.
COPY public."ScenarioAccounts" (acc_id, sc_id) FROM '$$PATH$$/2987.dat';

--
-- Data for Name: Scenarios; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public."Scenarios" (sc_id, ft_id, description, http_status_code) FROM stdin;
\.
COPY public."Scenarios" (sc_id, ft_id, description, http_status_code) FROM '$$PATH$$/2988.dat';

--
-- Name: Accounts_acc_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval('public."Accounts_acc_id_seq"', 7, true);


--
-- Name: Features_ft_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval('public."Features_ft_id_seq"', 6, true);


--
-- Name: AccountResponses AccountResponses_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public."AccountResponses"
    ADD CONSTRAINT "AccountResponses_pkey" PRIMARY KEY (acr_id);


--
-- Name: Accounts Accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public."Accounts"
    ADD CONSTRAINT "Accounts_pkey" PRIMARY KEY (acc_id);


--
-- Name: Features Features_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public."Features"
    ADD CONSTRAINT "Features_pkey" PRIMARY KEY (ft_id);


--
-- Name: ParamScenarios ParamScenarios_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public."ParamScenarios"
    ADD CONSTRAINT "ParamScenarios_pkey" PRIMARY KEY (ps_id);


--
-- Name: Scenarios Scenarios_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public."Scenarios"
    ADD CONSTRAINT "Scenarios_pkey" PRIMARY KEY (sc_id);


--
-- Name: ParamScenarios ParamScenarios_sc_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public."ParamScenarios"
    ADD CONSTRAINT "ParamScenarios_sc_id_fkey" FOREIGN KEY (sc_id) REFERENCES public."Scenarios"(sc_id);


--
-- Name: ScenarioAccountResponses ScenarioAccountResponses_acr_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public."ScenarioAccountResponses"
    ADD CONSTRAINT "ScenarioAccountResponses_acr_id_fkey" FOREIGN KEY (acr_id) REFERENCES public."AccountResponses"(acr_id) NOT VALID;


--
-- Name: ScenarioAccountResponses ScenarioAccountResponses_sc_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public."ScenarioAccountResponses"
    ADD CONSTRAINT "ScenarioAccountResponses_sc_id_fkey" FOREIGN KEY (sc_id) REFERENCES public."Scenarios"(sc_id) NOT VALID;


--
-- Name: ScenarioAccounts ScenarioAccounts_acc_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public."ScenarioAccounts"
    ADD CONSTRAINT "ScenarioAccounts_acc_id_fkey" FOREIGN KEY (acc_id) REFERENCES public."Accounts"(acc_id) NOT VALID;


--
-- Name: ScenarioAccounts ScenarioAccounts_sc_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public."ScenarioAccounts"
    ADD CONSTRAINT "ScenarioAccounts_sc_id_fkey" FOREIGN KEY (sc_id) REFERENCES public."Scenarios"(sc_id) NOT VALID;


--
-- Name: Scenarios Scenarios_ft_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public."Scenarios"
    ADD CONSTRAINT "Scenarios_ft_id_fkey" FOREIGN KEY (ft_id) REFERENCES public."Features"(ft_id);


--
-- PostgreSQL database dump complete
--

